//根据指定的id值获取元素对象
function $$(id){
    //返回id对应的元素对象
    return document.getElementById(id);
}