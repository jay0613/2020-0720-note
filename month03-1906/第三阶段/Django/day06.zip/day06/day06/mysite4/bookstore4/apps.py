from django.apps import AppConfig


class Bookstore4Config(AppConfig):
    name = 'bookstore4'
