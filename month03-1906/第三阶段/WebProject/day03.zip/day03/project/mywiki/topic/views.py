import json

from django.http import JsonResponse
from django.shortcuts import render
from tools.logging_check import logging_check
from .models import *

# Create your views here.
@logging_check('POST')
def topics(request, author_id):

    if request.method == 'POST':
        #TODO 校验request.user.username == author_id
        json_str = request.body
        if not json_str:
            result = {'code': 10300, 'error':'Please give me data'}
            return JsonResponse(result)
        json_obj = json.loads(json_str)
        title = json_obj.get('title', '')
        if not title:
            result = {'code': 10301, 'error':'Please give me title'}
            return JsonResponse(result)
        #带有html标签样式的博客内容
        content = json_obj.get('content')
        #纯文本的博客内容
        content_text = json_obj.get('content_text')
        if not content or not content_text:
            result = {'code': 10302, 'error':'Please give me content !'}
            return JsonResponse(result)
        #生成简介部分
        introduce = content_text[:30]
        limit = json_obj.get('limit')
        #校验limit
        if limit not in ('public', 'private'):
            result = {'code':10303, 'error': 'Your limit is not ok!'}
            return JsonResponse(result)
        category = json_obj.get('category')
        #校验category
        if category not in ('tec', 'no-tec'):
            result = {'code': 10304, 'error':'Your category is not ok!'}
            return JsonResponse(result)


        Topic.objects.create(title=title,category=category,limit=limit,introduce=introduce,content=content, author=request.user)

        result = {'code':200, 'username':request.user.username}
        return JsonResponse(result)































    return JsonResponse({'code':200000})



