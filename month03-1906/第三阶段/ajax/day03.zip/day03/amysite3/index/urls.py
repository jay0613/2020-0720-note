from django.conf.urls import url
from . import views


urlpatterns = [

    url(r'^test_load$', views.test_load),
    url(r'^test_load_server$', views.test_load_server),
    url(r'^test_jquery_get$', views.test_jquery_get),
    url(r'^test_jquery_get_server$', views.test_jquery_get_server),
url(r'^test_jquery_post$', views.test_jquery_post),
url(r'^test_jquery_post_server$', views.test_jquery_post_server),

url(r'^test_jquery_ajax$', views.test_jquery_ajax),
url(r'^test_jquery_ajax_server$', views.test_jquery_ajax_server),

url(r'^get_user$', views.get_user),
url(r'^get_user_server$', views.get_user_server),

url(r'^cross$', views.cross),
    url(r'^cross_server$', views.cross_server)



]