from django.http import JsonResponse, HttpResponse
from django.shortcuts import render

# Create your views here.
def test_load(request):

    return render(request, 'index/test_load.html')


def test_load_server(request):
    #GET传参 获取值
    name = request.GET.get('name')
    print(111111111)
    print(name)

    return render(request, 'index/test_load_server.html')

def test_jquery_get(request):
    #测试 jquery get方法
    return render(request, 'index/test_jquery_get.html')


def test_jquery_get_server(request):

    d = {'name':'guoxiaonao', 'age':18}
    return JsonResponse(d)

def test_jquery_post(request):

    return render(request, 'index/test_jquery_post.html')


def test_jquery_post_server(request):

    name = request.POST.get('name')

    return JsonResponse({'name':name})

def test_jquery_ajax(request):

    return render(request, 'index/test_jquery_ajax.html')

def test_jquery_ajax_server(request):

    import time
    time.sleep(3)

    return JsonResponse({'name':'guoxiaonao'})

def get_user(request):

    return render(request,'index/get_user.html')

def get_user_server(request):

    users = [{'name':'guoxiaonao', 'age':18},{'name':'guoxiaonao2', 'age':21}]
    import json
    user_str = json.dumps(users)
    return HttpResponse(user_str, content_type='application/json')


def cross(request):

    return render(request, 'index/cross.html')

def cross_server(request):

    # func = request.GET.get('callback')
    # #res = "print('wo kua chu lai le')"
    #
    # return HttpResponse(func + "('wo kua chu lai le hahaha')")
    import json
    func = request.GET.get('callback')
    d = {'name':'guoxiaonao', 'age':18}
    return HttpResponse(func + "(" + json.dumps(d) + ")")















































