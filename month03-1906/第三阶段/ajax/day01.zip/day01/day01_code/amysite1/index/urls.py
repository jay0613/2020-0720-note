from django.conf.urls import url
from . import views

urlpatterns = [
    #http://127.0.0.1:8000/index/xhr
    url(r'^xhr$', views.xhr_view),
    #http://127.0.0.1:8000/index/xhr_get
    url(r'^xhr_get$', views.xhr_get),
    #http://127.0.0.1:8000/index/xhr_get_server
    url(r'^xhr_get_server$', views.xhr_get_server),
    #http://127.0.0.1:8000/index/check_username
    url(r'^check_username$', views.check_username),
    #http://127.0.0.1:8000/index/register
    url(r'^register$', views.register)
]