from django.http import HttpResponse
from django.shortcuts import render
from .models import User
# Create your views here.
def xhr_view(request):

    return render(request, 'index/xhr.html')

def xhr_get(request):

    return render(request, 'index/xhr_get.html')

def xhr_get_server(request):
    if request.GET.get('params'):
        p = request.GET['params']
        return HttpResponse('%s is received'%(p))
    return HttpResponse('This is ajax !')

def register(request):

    return render(request, 'index/register.html')

def check_username(request):
    #检查用户名
    username = request.GET.get('username')
    #filter
    users = User.objects.filter(username=username)
    if users:
        return HttpResponse('用户名已存在')
    return HttpResponse('ok')









